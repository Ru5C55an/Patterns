//
//  Safe.swift
//  Singleton
//
//  Created by Руслан Садыков on 21.12.2020.
//


class Safe {
    
    var money = 0
    static let shared = Safe()
    
    
    private init() {
        
    }
}

